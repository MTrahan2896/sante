<?php
include 'queryFunctions.php';

 echo phpQuery('delete from groupes where ID_Groupe = '.$_POST['id_groupe'])?>
?>



