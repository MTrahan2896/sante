   
   document.write("\<script src='//ajax.googleapis.com/ajax/libs/jquery/1.2.6/jquery.min.js' type='text/javascript'>\<\/script>");


   function Close_Open_Modal(close_modal_id,open_modal_id)
  {
     $(close_modal_id).modal('close');
      $(open_modal_id).modal('open');
     
  }  

