<script>
var app = angular.module("app_test", []); 
app.controller("ctrl", function($scope) {




$scope.test = function(){
	console.log($scope.NA+" VALEUR");
}

});

</script>