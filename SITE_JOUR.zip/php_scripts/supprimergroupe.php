<?php
include_once 'queryfunctions.php';

 echo phpQuery('delete from groupes where ID_Groupe = '.$_POST['id_groupe'])?>
?>



